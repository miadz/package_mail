<?php
return [

    'name_min_length' => 5,
    'name_min_length' => 153
];