setTimeout(function () {
    $('.flash-message').fadeOut('fast');
}, 30000);